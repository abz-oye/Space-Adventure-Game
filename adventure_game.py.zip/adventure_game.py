import time
import random
inventory = []
weapon = random.choice(["Laser Canon", "Laser Blaster",
                        "Sonic Disc", "Super-Sonic Gun",
                        "Cyber Gauntlet", "Plasma Sheild",
                        "Hyper Grenade", "Cosmic Sword"])


def print_pause(message):
    print(message)
    time.sleep(2)


def defeat():
    print_pause("\nGAME OVER\n\n")
    play_again()


def victory():
    print_pause("\nVICTORY - YOU WIN\n\n")
    play_again()


def combat():
    print_pause("\nYour health is at 100%")
    print_pause("The Aliens's health is at 100%\n")
    alien_health = 100
    your_health = 100
    while alien_health >= 0 and your_health >= 0:
        alien_damage = random.randint(0, 100)
        your_damage = random.randint(0, 100)
        alien_health = alien_health - alien_damage
        your_health = your_health - your_damage
        print_pause(f"The Alien does {your_damage} damage.")
        print_pause(f"Your health is now at {your_health}%.\n")
        if your_health <= 0:
            print_pause("Oh No, You have been defeated.\n")
            defeat()
        print_pause(f"You use your {weapon} to do {alien_damage} damage.")
        print_pause(f"The Alien's health is now at {alien_health}%.\n")
        if alien_health <= 0:
            print_pause("You defeated the Alien, hooray!\n")
            victory()


def play_again():
    again = input("Would you like to play again? (y/n)\n").lower()
    if again == 'y':
        print_pause("Excellent, resetting game now ...")
        inventory.clear()
        game()
    elif again == 'n':
        print_pause("OK, Bye")
        exit()
    else:
        play_again()


def intro():
    print_pause("You find yourself onboard a spaceship deck in the middle"
                f" of space holding a {weapon}.")
    print_pause("Recently, there has been a some research on an alien"
                " creature which is being tested on.\n...")
    print_pause("In front of you is a research facility:"
                " which says 'KEEP OUT!'")
    print_pause("To the right of you is a robotics lab"
                " with a door slightly open.\n\n")


def research_facility():
    print_pause("You approach the door of the research facility.")
    print_pause("You grab the door of the handle and"
                " gradually open the door.\n")
    print_pause("Immediately a black alien leaps towards you"
                " and starts attacking you")
    print_pause("However, at the side of the lab you see "
                " a flask full of acid which has a label"
                " attatched to it which reads: 'ANTI-ALIEN FORMULA'.")
    formula_or_fight = input(f"Would you like to fight with "
                             " your {weapon} (1) or pour the"
                             " formula over the alien and escape (2)?  ")
    if formula_or_fight == '1':
        print_pause("I see you have chosen to fight.")
        if "Quantum Cube" in inventory:
            print_pause("With the Quantum Cube in your hands,"
                        " you press the button in the middle")
            print_pause("Almost instantly a miniature black hole upons up and"
                        " swallows the alien straight in.")
            victory()
        elif "Quantum Cube" not in inventory:
            combat()
        else:
            decisions()

    elif formula_or_fight == '2':
        print_pause("You grab the anti-alien formula.")
        print_pause("You pour it on the alien.")
        print_pause("Luckily, the alien starts to retreat,"
                    " however it wasn't very effective.")
        print_pause("You manage to escape out of the research facility"
                    " just in the nick of time.")
        print_pause("You make your way back to the corridor.")
        decisions()


def robotics_lab():
    print_pause("You approach the door to the robotics lab.")

    if "Quantum Cube" in inventory:
        print_pause("You have already been here and got what you needed.")
        print_pause("You make your way back to the corridor.")
        decisions()
    else:
        print_pause("You enter the lab and find it's dark"
                    " and the lights are lightly dimed.")
        print_pause("In the middle of the room is a "
                    " large glass cube holding an object.")
        print_pause("As you walk further you recognise the object - it is"
                    " the legendry Quantum Cube, capable of"
                    " destroying almost anything!")
        print_pause("You take the cube and put it in your inventory.")
        print_pause("You make your way back to the corridor.")
        inventory.append("Quantum Cube")
        decisions()


def decisions():
    print_pause("\nEnter 1 to go into the Research Facility.\n"
                "Enter 2 to go into the Robotics Lab.")
    print_pause("What would you like to do?")
    response = input("(Please enter 1 or 2)\n")
    if response == '1':
        research_facility()
    elif response == '2':
        robotics_lab()
    else:
        decisions()


def game():
    intro()
    decisions()
    play_again()


game()
